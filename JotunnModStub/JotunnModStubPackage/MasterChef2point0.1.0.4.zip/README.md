**MOD Description** 

Master Chef 2.0 is a partial remake of Master Chef with 3d models by deBARBA
Please support his artwork he made some really amazing models for this 

You can find him here:
patreon.com/littleroomdev 


I have permission from hrve to remake master chef and can furnish proof if needed 


You will get 6 new food items with this mod and 1 new wearable item

Burger
Blood Sausage
Broth
Carrot Butter
Carrot Butter Jelly Sandwich
Dragon Omlette
Fish Stew


and finally a Chef Hat as a wearable item. 


---
**Installation**

1) Go to [BepInExPack Valheim](https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/)
2) Download it and follow the installation manual
3) Drag the unzipped MasterChef20 folder into -> <Steam Location>\steamapps\common\Valheim\BepInEx\plugin\  

The next time you start your game, the mod will be enabled. To disable it, just remove it from the mods folder.

---
**Usage**

Recipes should appear in game through normal play. If you are installing this mod on an existing playthrough, you will have to pick up items or re-order you inventory to learn the new recipes.

---
I wanna extend a huge thank you to Jotunn team they are amazing and basically enabled me to make this project :D 

--- 
**Changelog**

**v1.0.0**

* initial release 

**v1.0.1**

* readme updates

**v1.0.2**

* readme updates


**v1.0.3**

* Fixed missing description in burger 

**v1.0.4**

Updated NuGet package in Visual Studio to align with latest lib release
Updated Bepinexpack to 5.4.11
