Introducing the newest fad in Viking cuisine! Hope you enjoy, Bone Appetit!

v. 1.0.0 release includes 2 food crafting stations that require a fire underneath to cook on, and 5 new food items, one for each biome.

Cooking Stations
Griddle  - buildable with 10 stone and a hammer. Allows for custom food as soon as you find a place to build it.
Grill       - requires a forge, 1 iron and 10 stone to build. unlock higher tier grilled foods.

Food included in initial release
Pork Rinds
Honey Glazed Carrots
Kabobs
Ice Cream Cone
Country Fried Lox Meat


To Do/ Current Ideas
-add food menu items (in progress with permission from zarboz)
-expand menu
-localizaion
-add another new processing station for food
-add new food drops from creatures
-meals/config sync

This mod is routinely tested on a dedicated server with a great many other mods. To ensure your crafting stations don't disappear, and that food doesn't vanish, please put on the dedicated server as well as ALL clients.


Huge thanks to zarboz, GraveBear, and plumga for helping me get going, setting me up, and encouraging me the whole way! This mod wouldn't exist without them.