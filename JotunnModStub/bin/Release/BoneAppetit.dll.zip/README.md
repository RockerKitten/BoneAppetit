Introducing the newest fad in Viking cuisine! Hope you enjoy, Bone Appetit!

Changelog
v. 1.0.0 	release includes 2 food crafting stations that require a fire underneath to cook on, and 5 new food items, one for each biome.
v. 1.0.1 	hotfix for those not using V+
v. 1.1.0 	fix for the grill making it difficult to load the fire underneath
			fix for Fried Lox not auto picking up
			5 new foods. Pancakes, Smoked Fish, Bacon, Coffee, and Pizza
v. 1.1.1	updated visuals on bacon
			Fixed collider on Griddle
			Fixed attach point on kabob
			

Note: this mod requires JVL (Jotunn the Valheim Lib) it will not work without it.

Cooking Stations
Griddle  - buildable with 10 stone and a hammer. Allows for custom food as soon as you find a place to build it.
Grill       - requires a forge, 1 iron and 10 stone to build. unlock higher tier grilled foods.

Food included in initial release
Pork Rinds
Honey Glazed Carrots
Kabobs
Ice Cream Cone
Country Fried Lox Meat

v. 1.1.0
Smoked Fish

Food Menu Assets Courtesy of zarboz
-Bacon
-Coffee
-Pizza
-Pancakes


To Do/ Current Ideas
x-add food menu items (done)
-expand menu (In progress)
-localizaion
-add another new processing station for food and expansions
-add new food drops from creatures
-meals/config sync

This mod is routinely tested on a dedicated server with a great many other mods. To ensure your crafting stations don't disappear, and that food doesn't turn to dust, please put on the dedicated server as well as ALL clients.


Huge thanks to zarboz, GraveBear, and plumga for helping me get going, setting me up, and encouraging me the whole way! This mod wouldn't exist without them.